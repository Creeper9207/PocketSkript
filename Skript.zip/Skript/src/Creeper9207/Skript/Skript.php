<?php

namespace Creeper9207\Skript;

use pocketmine\plugin\PluginBase;

class Skript extends PluginBase {
    
    public function onEnable() {
        try {
            
            \Phar::mount("plugins", "plugins");
            
        } catch (Exception $ex) {
            print_r($ex);
        }
        $this->getLogger()->info("onEnable() has been called!");
        Test::run();
    }
    public function onDisable() {
        
    }
    
    
    
}

