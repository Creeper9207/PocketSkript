<?php

namespace Creeper9207\Skript;

class Test {
    
    public static function run() {
        mkdir('plugins\Skript\scripts');
        //$txt = "(e(1)) ( (e((2(e))34))";
        $txt = "(amount|number[hu2 [e]]|size[hi [h3]]) [der (kamph)] of %objects% \"poopy woopy\"";
        $e=array();
        $b=array();
        $strings=array();
        $bc=0;
        $ec=0;
        preg_match_all("/(?=(\((?>[^()]++|(?1))*\)))/", $txt,  $matches);
        $new = array_reverse(array_reverse($matches[1]));
        $final="";
        foreach ($new as $key => $value) {
            //$final = $final."\n".str_replace($value, "::e".$key."e::", $new[$key]);;
            $txt=str_replace($value, "::p".$key."p::", $txt);
            $e[$key] = $value;
            $new[$key] = str_replace($value, "::p".$key."p::", $new[$key]);
            
            $ec=$ec+1;
        }
        foreach ($e as $key => $value) {
            
            foreach (array_reverse($e) as $keyI => $valueI) {
                if ($value != $valueI) {
                    //echo("Search for: ".$valueI." in ".$value.": ".str_replace($valueI, "::p".$keyI."p::", $value)." ".$key."\n");
                    if (strpos($value,$valueI) !== false) {
                        $e[$key] = str_replace($valueI, "::p".$keyI."p::", $value);
                        
                        
                        
                    }
                }
            }
            
        }
        //parse brackets
        preg_match_all("/(?=(\[(?>[^][]++|(?1))*]))/", $txt,  $matches);
        $newb = array_reverse(array_reverse($matches[1]));
        $final="";
        foreach ($newb as $key => $value) {
            //$final = $final."\n".str_replace($value, "::e".$key."e::", $new[$key]);;
            $txt=str_replace($value, "::b".$key."b::", $txt);
            $b[$key] = $value;
            $newb[$key] = str_replace($value, "::b".$key."b::", $newb[$key]);
            
            $bc=$bc+1;
        }
        
      
        
        foreach ($e as $key => $value) {
            
            preg_match_all("/(?=(\[(?>[^][]++|(?1))*]))/", $value,  $matches);
            
            foreach ($matches[1] as $keyI => $valueI) {
                $e[$key] = str_replace($valueI, "::b".$bc."b::", $e[$key]);
                $b[$bc] = $valueI;
                $bc=$bc+1;
            }
            
        }
        
        foreach ($b as $key => $value) {
            
            foreach (array_reverse($b) as $keyI => $valueI) {
                if ($value != $valueI) {
                    //echo("Search for: ".$valueI." in ".$value.": ".str_replace($valueI, "::b".$keyI."b::", $value)." ".$key."\n");
                    if (strpos($value,$valueI) !== false) {
                        $b[$key] = str_replace($valueI, "::b".$keyI."b::", $value);
                        
                        
                        
                    }
                }
            }
            
        }
        
        //print_r($new);
        //print_r($e);
        //print_r($newb);
        //print_r($b);
        
        preg_match_all('/"([^"]*)"/', $txt, $matches);
        
        foreach ($matches[0] as $key => $value) {
            
            $strings[$key] = $value;
            $txt = str_replace($value, "::s".$key."s::", $txt);
        }
        
        print_r($strings);
        
        $st1 = explode(" ", $txt);
        
        print_r($st1);
        
        $file = fopen("plugins\Skript\debug.txt", "w"); 
        fwrite($file, $txt);
        fclose($file);
    
        
    }
    
}
