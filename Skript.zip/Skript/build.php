<?php
$srcRoot = "src/Creeper9207/Skript";
$buildRoot = "build";
 
$phar = new Phar($buildRoot . "/myapp.phar", 
    FilesystemIterator::CURRENT_AS_FILEINFO |       FilesystemIterator::KEY_AS_FILENAME, "myapp.phar");
$phar[$srcRoot . "/Skript.php"] = file_get_contents($srcRoot . "/Skript.php");
$phar[$srcRoot . "/Test.php"] = file_get_contents($srcRoot . "/Test.php");
$phar[$srcRoot . "/ParseExpr.php"] = file_get_contents($srcRoot . "/ParseExpr.php");
$phar["plugin.yml"] = file_get_contents("plugin.yml");
$phar->setStub($phar->createDefaultStub("$srcRoot . /Skript.php"));

//copy($srcRoot . "/config.ini", $buildRoot . "/config.ini");